"use strict";

/* Hente Alle DOM-elementer */

const getRedCar = document.querySelector("#redcar");
const getBlueCar = document.querySelector("#blueCar");
const getPoliceCar = document.querySelector("#policeCar");
const sun = document.querySelector(".sun");
const scene = document.querySelector(".scene");

/* Oprette lydobjekter */

const soundRedCar = new Audio();
soundRedCar.src = "../sound/redCarHorn.wav";
const soundPoliceCar = new Audio();
soundPoliceCar.src = "../sound/policeCarSound.wav";
const soundBlueCar = new Audio();
soundBlueCar.src = "../sound/blueCarSound.wav";

/* Tjeck om den røde bil (getRedCar) med ID attributten "redcar" findes i DOM'en */
if (getRedCar) {
    getRedCar.addEventListener("click", () => {
        soundRedCar.play();
    });
}

/* Tjeck om den Politibilen (getPoliceCar) med ID attributten "policecar" findes i DOM'en */
if (getPoliceCar) {
    getPoliceCar.addEventListener("click", () => {
        soundPoliceCar.play();
    });
}

/* Tjeck om den blå bil (getBlueCar) med ID attributten "bluecar" findes i DOM'en */
if (getBlueCar) {
    getBlueCar.addEventListener("click", () => {
        soundBlueCar.play();
    });
}

if (sun && scene) {
    sun.addEventListener("click", () => {
        scene.classList.toggle("night");
    });

}